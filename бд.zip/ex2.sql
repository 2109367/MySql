SELECT sp.*
FROM SouvenirProcurements AS sp
WHERE sp.Date BETWEEN '15.02.2024' AND '23.07.2024';
