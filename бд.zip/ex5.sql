SELECT sp.*, ps.name AS Status_name
FROM SouvenirProcurements sp
JOIN ProcurementStatuses ps ON sp.IdStatus = ps.id
WHERE sp.Date BETWEEN '01.01.2024' AND '31.12.2024'
ORDER BY ps.Name;