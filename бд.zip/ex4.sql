SELECT DISTINCT p.*
FROM Providers p
JOIN SouvenirProcurements sp ON p.id = sp.IdProvider
JOIN Procurementsouvenirs ps ON sp.id = ps.IdProcurement
JOIN Souvenirs s ON ps.idsouvenir = s.id
JOIN SouvenirsCategories sc ON s.IdCategory = sc.id
WHERE sc.name = '�������';